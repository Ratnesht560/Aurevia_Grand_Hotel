from django.urls import path

from rooms import views

app_name = "rooms"

urlpatterns = [
    path("", views.room_list, name="list"),
    path("types/", views.roomtype_list, name="types"),
    path("types/create/", views.roomtype_create, name="type_create"),
    path("types/<int:pk>/edit/", views.roomtype_edit, name="type_edit"),
    path("types/<int:pk>/delete/", views.roomtype_delete, name="type_delete"),
    path("create/", views.room_create, name="create"),
    path("<int:pk>/edit/", views.room_edit, name="edit"),
    path("<int:pk>/delete/", views.room_delete, name="delete"),
    path("<int:pk>/mark-available/", views.room_mark_available, name="mark_available"),
    path("availability/", views.availability, name="availability"),
]
