"""Hotel settings, currency/tax, notifications and appearance."""
from django.contrib import messages
from django.shortcuts import redirect, render

from core.decorators import staff_required
from core.models import Hotel, NotificationSetting, UserProfile
from settings_app.forms import CurrencyForm, HotelForm, NotificationForm

# Allowed appearance colours (champagne gold default).
PRIMARY_COLORS = [
    ("#C9A86A", "Champagne Gold"),
    ("#16866A", "Emerald"),
    ("#0B1F33", "Midnight Navy"),
    ("#8A6D3B", "Antique Bronze"),
    ("#2C7DA0", "Ocean Blue"),
    ("#7B4B94", "Royal Plum"),
]


@staff_required
def index(request):
    hotel = Hotel.get_instance()
    notifications = NotificationSetting.get_instance()
    profile = UserProfile.get_or_create_for(request.user)

    hotel_form = HotelForm(instance=hotel)
    currency_form = CurrencyForm(instance=hotel)
    notification_form = NotificationForm(instance=notifications)

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "hotel":
            hotel_form = HotelForm(request.POST, request.FILES, instance=hotel)
            if hotel_form.is_valid():
                hotel_form.save()
                messages.success(request, "Hotel information saved.")
                return redirect("settings_app:index")
        elif action == "currency":
            currency_form = CurrencyForm(request.POST, instance=hotel)
            if currency_form.is_valid():
                currency_form.save()
                messages.success(request, "Currency and tax settings saved.")
                return redirect("settings_app:index")
        elif action == "notifications":
            notification_form = NotificationForm(request.POST, instance=notifications)
            if notification_form.is_valid():
                notification_form.save()
                messages.success(request, "Notification preferences saved.")
                return redirect("settings_app:index")
        elif action == "appearance":
            theme = request.POST.get("theme", profile.theme)
            color = request.POST.get("primary_color", profile.primary_color)
            profile.theme = theme
            if color in [c[0] for c in PRIMARY_COLORS]:
                profile.primary_color = color
            profile.save()
            messages.success(request, "Appearance updated.")
            return redirect("settings_app:index")

    return render(
        request,
        "settings/index.html",
        {
            "hotel_form": hotel_form,
            "currency_form": currency_form,
            "notification_form": notification_form,
            "hotel": hotel,
            "profile": profile,
            "primary_colors": PRIMARY_COLORS,
        },
    )
