"""Payment history and receipt views."""
from datetime import date

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, redirect, render

from bookings.models import Reservation
from core.decorators import admin_or_manager_required, staff_required
from core.utils import next_payment_id
from payments.forms import PaymentForm
from payments.models import Payment


@staff_required
def payment_list(request):
    qs = Payment.objects.select_related("reservation", "customer", "reservation__room")
    q = request.GET.get("q", "").strip()
    method = request.GET.get("method", "")
    start = request.GET.get("start", "")
    end = request.GET.get("end", "")

    if q:
        qs = qs.filter(
            Q(payment_id__icontains=q)
            | Q(reference__icontains=q)
            | Q(reservation__booking_id__icontains=q)
            | Q(customer__first_name__icontains=q)
            | Q(customer__last_name__icontains=q)
        )
    if method:
        qs = qs.filter(method=method)
    if start:
        qs = qs.filter(date__date__gte=start)
    if end:
        qs = qs.filter(date__date__lte=end)

    total = qs.aggregate(total=Sum("amount"))["total"] or 0
    paginator = Paginator(qs, 20)
    page = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "payments/payment_list.html",
        {
            "payments": page,
            "filters": {"q": q, "method": method, "start": start, "end": end},
            "methods": Payment.Method.choices,
            "total": total,
        },
    )


@admin_or_manager_required
def payment_create(request):
    form = PaymentForm()
    booking_pk = request.GET.get("booking")
    if booking_pk:
        form = PaymentForm(initial={"reservation": booking_pk})
    if request.method == "POST":
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.payment_id = next_payment_id()
            payment.customer = payment.reservation.customer
            payment.save()
            payment.reservation.sync_payment_status()
            payment.reservation.save(update_fields=["payment_status", "updated_at"])
            messages.success(request, f"Payment {payment.payment_id} recorded.")
            return redirect("payments:list")
    reservation = None
    if booking_pk:
        reservation = (
            Reservation.objects.select_related("customer", "room")
            .filter(pk=booking_pk)
            .first()
        )
    return render(
        request,
        "payments/payment_form.html",
        {"form": form, "reservation": reservation},
    )


@staff_required
def payment_receipt(request, pk):
    payment = get_object_or_404(
        Payment.objects.select_related("reservation", "customer", "reservation__room"),
        pk=pk,
    )
    return render(request, "payments/receipt.html", {"payment": payment})
