from django import forms

from rooms.models import Room, RoomType


class RoomTypeForm(forms.ModelForm):
    class Meta:
        model = RoomType
        fields = [
            "name", "description", "max_occupancy", "base_price",
            "beds", "amenities", "image", "is_active",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "e.g. Deluxe"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "max_occupancy": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "base_price": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01"}),
            "beds": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "amenities": forms.Textarea(attrs={"class": "form-control", "rows": 2}),
            "image": forms.FileInput(attrs={"class": "form-control"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }


class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = [
            "room_number", "room_type", "floor", "status",
            "price_override", "description", "amenities", "image", "is_active",
        ]
        widgets = {
            "room_number": forms.TextInput(attrs={"class": "form-control", "placeholder": "e.g. 201"}),
            "room_type": forms.Select(attrs={"class": "form-select"}),
            "floor": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "status": forms.Select(attrs={"class": "form-select"}),
            "price_override": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "amenities": forms.Textarea(attrs={"class": "form-control", "rows": 2}),
            "image": forms.FileInput(attrs={"class": "form-control"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
