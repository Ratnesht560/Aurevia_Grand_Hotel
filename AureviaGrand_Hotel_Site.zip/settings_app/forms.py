from django import forms

from core.models import Hotel, NotificationSetting


class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = [
            "name", "tagline", "logo", "address", "city", "state", "country",
            "phone", "email", "website", "checkin_time", "checkout_time",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "tagline": forms.TextInput(attrs={"class": "form-control"}),
            "logo": forms.FileInput(attrs={"class": "form-control"}),
            "address": forms.TextInput(attrs={"class": "form-control"}),
            "city": forms.TextInput(attrs={"class": "form-control"}),
            "state": forms.TextInput(attrs={"class": "form-control"}),
            "country": forms.TextInput(attrs={"class": "form-control"}),
            "phone": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "website": forms.URLInput(attrs={"class": "form-control"}),
            "checkin_time": forms.TimeInput(attrs={"class": "form-control", "type": "time"}),
            "checkout_time": forms.TimeInput(attrs={"class": "form-control", "type": "time"}),
        }


class CurrencyForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ["currency_symbol", "currency_code", "tax_percentage"]
        widgets = {
            "currency_symbol": forms.TextInput(attrs={"class": "form-control", "placeholder": "₹"}),
            "currency_code": forms.TextInput(attrs={"class": "form-control", "placeholder": "INR"}),
            "tax_percentage": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01"}),
        }


class NotificationForm(forms.ModelForm):
    class Meta:
        model = NotificationSetting
        fields = ["booking_created", "booking_checked_in", "booking_checked_out", "payment_received"]
        widgets = {
            "booking_created": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "booking_checked_in": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "booking_checked_out": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "payment_received": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }
