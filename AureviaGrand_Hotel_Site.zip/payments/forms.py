from django import forms

from payments.models import Payment


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ["reservation", "amount", "method", "reference", "notes"]
        widgets = {
            "reservation": forms.Select(attrs={"class": "form-select"}),
            "amount": forms.NumberInput(attrs={"class": "form-control", "min": "0.01", "step": "0.01"}),
            "method": forms.Select(attrs={"class": "form-select"}),
            "reference": forms.TextInput(attrs={"class": "form-control", "placeholder": "TXN reference"}),
            "notes": forms.Textarea(attrs={"class": "form-control", "rows": 2}),
        }

    def clean(self):
        cleaned = super().clean()
        amount = cleaned.get("amount")
        reservation = cleaned.get("reservation")
        if amount and amount <= 0:
            self.add_error("amount", "Amount must be greater than zero.")
        if reservation and amount:
            overpay = amount > (reservation.total + reservation.extra_charges_total) - reservation.amount_paid
            if overpay and reservation.booking_status in (
                reservation.BookingStatus.CHECKED_OUT,
                reservation.BookingStatus.CANCELLED,
            ):
                self.add_error("amount", "Amount exceeds the outstanding balance.")
        return cleaned
