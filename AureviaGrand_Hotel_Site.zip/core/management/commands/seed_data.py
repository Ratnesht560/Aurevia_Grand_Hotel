"""Seed realistic demo data for Aurevia Grand.

Usage:
    python manage.py seed_data
"""
import os
import random
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from bookings.models import AdditionalCharge, Reservation
from core.models import Hotel, NotificationSetting, UserProfile
from core.utils import next_booking_id, next_payment_id
from customers.models import Customer
from payments.models import Payment
from rooms.models import Room, RoomType

FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Rohan", "Kabir",
    "Ishaan", "Aryan", "Ayaan", "Dhruv", "Krishna", "Ayaan", "Reyansh", "Om",
    "Ananya", "Diya", "Aadhya", "Aarohi", "Myra", "Saanvi", "Anika", "Ira",
    "Priya", "Riya", "Kavya", "Navya", "Ishita", "Meera", "Sara", "Aisha",
]
LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Singh", "Patel", "Yadav", "Mishra", "Agarwal",
    "Kumar", "Rao", "Reddy", "Mehta", "Shah", "Chauhan", "Rathore", "Tiwari",
    "Dubey", "Pandey", "Tripathi", "Srivastava", "Bansal", "Jain", "Khan",
    "Kapoor", "Malhotra", "Chopra", "Sinha", "Das", "Nair", "Menon",
]
CITIES = [
    "Gonda", "Lucknow", "Delhi", "Mumbai", "Kolkata", "Varanasi", "Gorakhpur",
    "Bareilly", "Kanpur", "Agra", "Jaipur", "Bengaluru", "Hyderabad",
    "Chennai", "Pune", "Ahmedabad", "Bhopal", "Patna",
]
STATES = ["Uttar Pradesh", "Delhi", "Maharashtra", "West Bengal", "Rajasthan",
          "Karnataka", "Telangana", "Tamil Nadu", "Gujarat", "Madhya Pradesh",
          "Bihar"]
COUNTRIES = ["India"] * 9 + ["United States", "United Kingdom", "Nepal", "UAE", "Singapore"]
ID_TYPES = ["passport", "aadhaar", "pan", "driving_license", "other"]
AMENITIES = {
    "Standard": "Wi-Fi, TV, Air conditioning, Tea maker",
    "Deluxe": "Wi-Fi, TV, Air conditioning, Mini fridge, Tea maker, Bathrobe",
    "Premium": "Wi-Fi, Smart TV, Air conditioning, Mini bar, Coffee machine, Balcony",
    "Suite": "Wi-Fi, Smart TV, Air conditioning, Living area, Mini bar, Bathroom amenities, Safe",
    "Presidential Suite": "Wi-Fi, Smart TV, Air conditioning, Butler service, Jacuzzi, Private lounge, Safe",
}
DESCRIPTIONS = {
    "Standard": "Comfortable room with essential amenities for a restful stay.",
    "Deluxe": "Spacious room with upgraded furnishings and city views.",
    "Premium": "Elegant room featuring a private balcony and premium amenities.",
    "Suite": "A generous suite with a separate living area and luxury touches.",
    "Presidential Suite": "Our finest accommodation with butler service and exclusive facilities.",
}


class Command(BaseCommand):
    help = "Seed demo data: hotel, room types, rooms, customers, reservations and payments."

    def handle(self, *args, **options):
        self.stdout.write("Seeding Aurevia Grand demo data…")
        random.seed(2026)

        hotel = Hotel.get_instance()
        NotificationSetting.get_instance()

        self.ensure_users()
        room_types = self.ensure_room_types()
        rooms = self.ensure_rooms(room_types)
        customers = self.ensure_customers()

        self.seed_reservations(rooms, customers)
        self.sync_room_statuses(rooms)

        self.stdout.write(self.style.SUCCESS(
            f"Done. {RoomType.objects.count()} room types, {Room.objects.count()} rooms, "
            f"{Customer.objects.count()} customers, {Reservation.objects.count()} reservations, "
            f"{Payment.objects.count()} payments."
        ))

    # ------------------------------------------------------------------ users
    def _required_seed_password(self, key, development_default):
        password = os.environ.get(key)
        if password:
            return password
        if settings.DEBUG:
            return development_default
        raise CommandError(
            f"{key} must be set when SEED_DEMO_DATA is enabled in production."
        )

    def ensure_users(self):
        admin_username = os.environ.get("SEED_ADMIN_USERNAME", "admin")
        admin_email = os.environ.get(
            "SEED_ADMIN_EMAIL", "ratnesht560@gmail.com"
        )
        admin_password = self._required_seed_password("SEED_ADMIN_PASSWORD", "admin123")

        admin, created = User.objects.get_or_create(
            username=admin_username,
            defaults={
                "email": admin_email,
                "is_staff": True,
                "is_superuser": True,
                "is_active": True,
            },
        )
        if created:
            admin.set_password(admin_password)
            admin.save()
        else:
            changed = False
            if not admin.is_staff:
                admin.is_staff = True
                changed = True
            if not admin.is_superuser:
                admin.is_superuser = True
                changed = True
            if not admin.is_active:
                admin.is_active = True
                changed = True
            if admin_email and admin.email != admin_email:
                admin.email = admin_email
                changed = True
            if changed:
                admin.save()

        staff_specs = [
            (
                "manager",
                UserProfile.Role.MANAGER,
                "manager@aureviagrand.com",
                "SEED_MANAGER_PASSWORD",
            ),
            (
                "receptionist",
                UserProfile.Role.RECEPTIONIST,
                "reception@aureviagrand.com",
                "SEED_RECEPTIONIST_PASSWORD",
            ),
        ]
        for username, role, email, password_key in staff_specs:
            password = self._required_seed_password(password_key, "demo1234")
            user, was_created = User.objects.get_or_create(
                username=username,
                defaults={"email": email, "is_staff": True, "is_active": True},
            )
            if was_created:
                user.set_password(password)
                user.save()
            elif not user.is_staff:
                user.is_staff = True
                user.save(update_fields=["is_staff"])
            UserProfile.objects.get_or_create(user=user, defaults={"role": role})

        profile, _ = UserProfile.objects.get_or_create(
            user=admin, defaults={"role": UserProfile.Role.ADMIN}
        )
        profile.role = UserProfile.Role.ADMIN
        profile.save()

    # --------------------------------------------------------------- room data
    def ensure_room_types(self):
        specs = {
            "Standard": (4500, 2, 1),
            "Deluxe": (6500, 3, 2),
            "Premium": (9000, 3, 2),
            "Suite": (15000, 4, 2),
            "Presidential Suite": (35000, 6, 3),
        }
        types = []
        for name, (price, occ, beds) in specs.items():
            obj, _ = RoomType.objects.get_or_create(
                name=name,
                defaults={
                    "base_price": Decimal(price),
                    "max_occupancy": occ,
                    "beds": beds,
                    "amenities": AMENITIES[name],
                    "description": DESCRIPTIONS[name],
                    "is_active": True,
                },
            )
            types.append(obj)
        return types

    def ensure_rooms(self, room_types):
        if Room.objects.exists():
            return list(Room.objects.all())
        by_name = {t.name: t for t in room_types}
        mapping = {
            1: ["Standard", "Standard", "Standard", "Deluxe", "Deluxe", "Deluxe"],
            2: ["Deluxe", "Deluxe", "Deluxe", "Premium", "Premium", "Premium"],
            3: ["Premium", "Premium", "Premium", "Suite", "Suite", "Suite"],
            4: ["Suite", "Suite", "Suite", "Premium", "Premium", "Premium"],
            5: ["Presidential Suite", "Presidential Suite", "Suite", "Suite", "Deluxe", "Standard"],
        }
        rooms = []
        for floor, names in mapping.items():
            for idx, rtype in enumerate(names, start=1):
                number = f"{floor}{idx:02d}"
                room = Room.objects.create(
                    room_number=number,
                    room_type=by_name[rtype],
                    floor=floor,
                    status=Room.Status.AVAILABLE,
                    description=f"{rtype} on floor {floor}.",
                    amenities=AMENITIES[rtype],
                    is_active=True,
                )
                rooms.append(room)
        return rooms

    # ------------------------------------------------------------ customers
    def ensure_customers(self):
        if Customer.objects.exists():
            return list(Customer.objects.all())
        customers = []
        used = set()
        for i in range(24):
            first = random.choice(FIRST_NAMES)
            last = random.choice(LAST_NAMES)
            if (first, last) in used:
                continue
            used.add((first, last))
            customers.append(
                Customer.objects.create(
                    first_name=first,
                    last_name=last,
                    email=f"{first.lower()}.{last.lower()}@example.com",
                    phone=f"+91{random.randint(7000000000, 9999999999)}",
                    address=f"{random.randint(1, 999)} {random.choice(['MG Road', 'Station Road', 'Civil Lines', 'Park Street', 'Lake View'])}",
                    city=random.choice(CITIES),
                    state=random.choice(STATES),
                    country=random.choice(COUNTRIES),
                    id_type=random.choice(ID_TYPES),
                    id_number=f"{random.randint(1000, 9999)}{random.randint(1000, 9999)}{random.randint(1000, 9999)}",
                    date_of_birth=date(random.randint(1965, 2000), random.randint(1, 12), random.randint(1, 28)),
                )
            )
        return customers

    # ------------------------------------------------------------ reservations
    def seed_reservations(self, rooms, customers):
        if Reservation.objects.exists():
            return
        today = date.today()
        random.shuffle(rooms)
        used_per_room = {}  # room_id -> last checkout date
        active_pool = []
        for idx, room in enumerate(rooms):
            nights_room = random.randint(1, 3)
            for _ in range(nights_room):
                rng = random.random()
                if rng < 0.55:
                    check_in = today - timedelta(days=random.randint(2, 120))
                    check_out = check_in + timedelta(days=random.randint(1, 5))
                    status = Reservation.BookingStatus.CHECKED_OUT
                elif rng < 0.7:
                    check_in = today - timedelta(days=random.randint(2, 40))
                    check_out = check_in + timedelta(days=random.randint(1, 4))
                    status = random.choice([
                        Reservation.BookingStatus.CANCELLED,
                        Reservation.BookingStatus.NO_SHOW,
                    ])
                elif rng < 0.82:
                    check_in = today - timedelta(days=random.randint(0, 1))
                    check_out = check_in + timedelta(days=random.randint(1, 4))
                    status = Reservation.BookingStatus.CHECKED_IN
                else:
                    check_in = today + timedelta(days=random.randint(1, 30))
                    check_out = check_in + timedelta(days=random.randint(1, 6))
                    status = random.choice([
                        Reservation.BookingStatus.CONFIRMED,
                        Reservation.BookingStatus.PENDING,
                    ])
                customer = random.choice(customers)
                booking = Reservation.objects.create(
                    booking_id=next_booking_id(check_in),
                    customer=customer,
                    room=room,
                    check_in=check_in,
                    check_out=check_out,
                    adults=random.randint(1, 4),
                    children=random.randint(0, 2),
                    rate_per_night=room.rate,
                    discount=Decimal(random.choice([0, 0, 0, 500, 1000])),
                    booking_status=status,
                )
                booking.recalculate()
                booking.save()
                if status in (Reservation.BookingStatus.CHECKED_IN,):
                    booking.checkin_at = timezone.make_aware(
                        timezone.datetime.combine(check_in, timezone.datetime.min.time())
                    )
                    booking.save()
                if status == Reservation.BookingStatus.CHECKED_OUT:
                    booking.checkout_at = timezone.make_aware(
                        timezone.datetime.combine(check_out, timezone.datetime.min.time())
                    )
                    booking.save()

                self.seed_payments(booking)
                if status in (
                    Reservation.BookingStatus.CONFIRMED,
                    Reservation.BookingStatus.PENDING,
                    Reservation.BookingStatus.CHECKED_IN,
                ):
                    active_pool.append(booking)
        # additional charges on some checked-out bookings
        for booking in Reservation.objects.filter(booking_status=Reservation.BookingStatus.CHECKED_OUT):
            if random.random() < 0.5:
                desc = random.choice(["Minibar", "Laundry service", "Airport transfer", "Spa", "Late checkout"])
                AdditionalCharge.objects.create(
                    reservation=booking,
                    description=desc,
                    amount=Decimal(random.randint(500, 4000)),
                )
                booking.sync_payment_status()
                booking.save()

    def seed_payments(self, booking):
        total = booking.total
        if booking.booking_status in (
            Reservation.BookingStatus.CANCELLED,
            Reservation.BookingStatus.NO_SHOW,
        ):
            booking.payment_status = Reservation.PaymentStatus.UNPAID
            booking.save()
            return
        roll = random.random()
        if booking.booking_status == Reservation.BookingStatus.CHECKED_OUT:
            paid_fraction = Decimal("1.0") if roll < 0.8 else Decimal(random.choice(["0.5", "0.75", "0"]))
            method = random.choice([c[0] for c in Payment.Method.choices])
            if paid_fraction > 0:
                Payment.objects.create(
                    payment_id=next_payment_id(),
                    reservation=booking,
                    customer=booking.customer,
                    amount=(total * paid_fraction).quantize(Decimal("1")),
                    method=method,
                    reference=("TXN" + str(random.randint(100000, 999999)) if method != "cash" else ""),
                    date=timezone.now() - timedelta(days=random.randint(0, 120)),
                )
        else:
            # advance payment for current/future bookings
            fraction = random.choice(["0", "0", "0.25", "0.25", "0.5", "1"])
            method = random.choice([c[0] for c in Payment.Method.choices])
            if Decimal(fraction) > 0:
                Payment.objects.create(
                    payment_id=next_payment_id(),
                    reservation=booking,
                    customer=booking.customer,
                    amount=(total * Decimal(fraction)).quantize(Decimal("1")),
                    method=method,
                    reference=("TXN" + str(random.randint(100000, 999999)) if method != "cash" else ""),
                    date=timezone.now() - timedelta(days=random.randint(0, 5)),
                )
        booking.sync_payment_status()
        booking.save()

    def sync_room_statuses(self, rooms):
        today = date.today()
        for room in rooms:
            active = room.reservations.filter(
                booking_status__in=Reservation.ACTIVE_STATUSES,
                check_in__lte=today,
                check_out__gt=today,
            )
            upcoming = room.reservations.filter(
                booking_status__in=Reservation.ACTIVE_STATUSES,
                check_in__gt=today,
            )
            if active.exists():
                room.status = Room.Status.OCCUPIED
            elif upcoming.exists():
                room.status = Room.Status.RESERVED
            else:
                room.status = Room.Status.AVAILABLE
            room.save(update_fields=["status", "updated_at"])
        # a couple of housekeeping scenarios for realism
        cleaning_room = list(Room.objects.filter(status=Room.Status.AVAILABLE).order_by("?")[:2])
        Room.objects.filter(id__in=[r.id for r in cleaning_room]).update(status=Room.Status.CLEANING)
        maintenance_room = list(Room.objects.filter(status=Room.Status.AVAILABLE).order_by("?")[:1])
        Room.objects.filter(id__in=[r.id for r in maintenance_room]).update(status=Room.Status.MAINTENANCE)
        oos_room = list(Room.objects.filter(status=Room.Status.AVAILABLE).order_by("?")[:1])
        Room.objects.filter(id__in=[r.id for r in oos_room]).update(status=Room.Status.OUT_OF_SERVICE)
