/* Aurevia Grand — main application script */
(function () {
  "use strict";

  const sidebar = document.getElementById("sidebar");
  const backdrop = document.getElementById("sidebarBackdrop");
  const html = document.documentElement;

  /* ---------- Sidebar ---------- */
  function setSidebarCollapsed(collapsed) {
    if (!sidebar) return;
    sidebar.classList.toggle("collapsed", collapsed);
    document.body.classList.toggle("sidebar-collapsed", collapsed);
    try {
      localStorage.setItem("ag-sidebar", collapsed ? "1" : "0");
    } catch (e) { /* ignore */ }
  }

  const toggleBtn = document.getElementById("sidebarToggle");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", function () {
      if (window.innerWidth < 992) {
        sidebar.classList.toggle("open");
        backdrop.classList.toggle("show", sidebar.classList.contains("open"));
      } else {
        setSidebarCollapsed(!sidebar.classList.contains("collapsed"));
      }
    });
  }
  if (backdrop) {
    backdrop.addEventListener("click", function () {
      sidebar.classList.remove("open");
      backdrop.classList.remove("show");
    });
  }

  /* Restore collapsed state on desktop */
  try {
    if (localStorage.getItem("ag-sidebar") === "1" && window.innerWidth >= 992) {
      setSidebarCollapsed(true);
    }
  } catch (e) { /* ignore */ }

  /* Expandable nav groups */
  document.querySelectorAll(".nav-group > .nav-link").forEach(function (link) {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      const group = link.closest(".nav-group");
      const wasOpen = group.classList.contains("open");
      document.querySelectorAll(".nav-group.open").forEach(function (g) {
        g.classList.remove("open");
      });
      if (!wasOpen) group.classList.add("open");
    });
  });

  /* Mark nav group open when a child link is active */
  document.querySelectorAll(".nav-group").forEach(function (group) {
    if (group.querySelector(".nav-link.active")) {
      group.classList.add("open");
    }
  });

  /* ---------- Theme (persist to localStorage for the session) ---------- */
  function applyTheme(theme) {
    html.setAttribute("data-theme", theme);
  }
  if (html.dataset.theme) applyTheme(html.dataset.theme);

  /* ---------- Toasts ---------- */
  const stack = document.getElementById("toastStack");
  if (stack) {
    stack.querySelectorAll(".toast-glass").forEach(function (toast) {
      setTimeout(function () {
        toast.classList.add("hide");
        setTimeout(() => toast.remove(), 380);
      }, 4200);
    });
  }

  window.AureviaToast = function (type, message) {
    if (!stack) return;
    const icons = { success: "bi-check-circle", danger: "bi-x-circle", warning: "bi-exclamation-triangle", info: "bi-info-circle" };
    const el = document.createElement("div");
    el.className = "toast-glass toast-" + type;
    el.innerHTML =
      '<i class="bi ' + (icons[type] || icons.info) + '"></i>' +
      '<div style="font-size:13.5px;line-height:1.4">' + message + "</div>";
    stack.appendChild(el);
    setTimeout(function () {
      el.classList.add("hide");
      setTimeout(() => el.remove(), 380);
    }, 4200);
  };

  /* ---------- Confirm dialogs (forms with data-confirm) ---------- */
  document.addEventListener("submit", function (e) {
    const form = e.target;
    const msg = form.getAttribute("data-confirm");
    if (msg && !window.confirm(msg)) {
      e.preventDefault();
      e.stopPropagation();
    }
  });

  /* Confirmation modal links */
  document.querySelectorAll("[data-confirm-href]").forEach(function (a) {
    a.addEventListener("click", function (e) {
      e.preventDefault();
      const href = a.getAttribute("data-confirm-href");
      const msg = a.getAttribute("data-confirm-msg") || "Are you sure you want to do this?";
      if (window.confirm(msg)) window.location.href = href;
    });
  });

  /* ---------- Image preview ---------- */
  document.querySelectorAll("[data-preview]").forEach(function (input) {
    input.addEventListener("change", function () {
      const file = input.files && input.files[0];
      const target = document.querySelector(input.getAttribute("data-preview"));
      if (file && target && file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = function (ev) { target.src = ev.target.result; };
        reader.readAsDataURL(file);
      }
    });
  });

  /* ---------- Show/hide password ---------- */
  document.querySelectorAll(".toggle-pass").forEach(function (btn) {
    btn.addEventListener("click", function () {
      const input = document.getElementById(btn.getAttribute("data-target"));
      if (!input) return;
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.querySelector("i").className = "bi " + (show ? "bi-eye-slash" : "bi-eye");
    });
  });

  /* ---------- Print ---------- */
  document.querySelectorAll("[data-print]").forEach(function (btn) {
    btn.addEventListener("click", function () { window.print(); });
  });

  /* ---------- Auto-dismiss autofade alerts ---------- */
  document.querySelectorAll(".alert-dismissible").forEach(function (alert) {
    setTimeout(function () {
      alert.style.transition = "opacity .4s, transform .4s";
      alert.style.opacity = "0";
      alert.style.transform = "translateY(-6px)";
      setTimeout(() => alert.remove(), 420);
    }, 5000);
  });
})();
