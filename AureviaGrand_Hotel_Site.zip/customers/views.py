"""Customer management views."""
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from core.decorators import admin_or_manager_required, staff_required
from customers.forms import CustomerForm
from customers.models import Customer


@staff_required
def customer_list(request):
    qs = Customer.objects.all()
    q = request.GET.get("q", "").strip()
    city = request.GET.get("city", "").strip()
    view = request.GET.get("view", "table")

    if q:
        qs = qs.filter(
            Q(first_name__icontains=q)
            | Q(last_name__icontains=q)
            | Q(email__icontains=q)
            | Q(phone__icontains=q)
        )
    if city:
        qs = qs.filter(city__iexact=city)

    paginator = Paginator(qs, 12)
    page = paginator.get_page(request.GET.get("page"))

    context = {
        "customers": page,
        "query": q,
        "city": city,
        "view": view,
        "cities": Customer.objects.exclude(city="").order_by("city")
        .values_list("city", flat=True).distinct(),
    }
    return render(request, "customers/customer_list.html", context)


@staff_required
def customer_detail(request, pk):
    customer = get_object_or_404(
        Customer.objects.prefetch_related("reservations", "reservations__room", "reservations__payments"),
        pk=pk,
    )
    reservations = customer.reservations.select_related("room").all()
    payments = customer.payments.select_related("reservation").all()
    return render(
        request,
        "customers/customer_detail.html",
        {"customer": customer, "reservations": reservations, "payments": payments},
    )


@admin_or_manager_required
def customer_create(request):
    form = CustomerForm()
    if request.method == "POST":
        form = CustomerForm(request.POST, request.FILES)
        if form.is_valid():
            customer = form.save()
            messages.success(request, f"{customer.full_name} added as a guest.")
            return redirect("customers:detail", pk=customer.pk)
    return render(request, "customers/customer_form.html", {"form": form, "mode": "create"})


@admin_or_manager_required
def customer_edit(request, pk):
    obj = get_object_or_404(Customer, pk=pk)
    form = CustomerForm(instance=obj)
    if request.method == "POST":
        form = CustomerForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Guest profile updated.")
            return redirect("customers:detail", pk=obj.pk)
    return render(request, "customers/customer_form.html", {"form": form, "mode": "edit", "object": obj})


@admin_or_manager_required
def customer_delete(request, pk):
    obj = get_object_or_404(Customer, pk=pk)
    if request.method == "POST":
        if obj.reservations.exists():
            messages.error(request, "Cannot delete a guest with reservation history.")
        else:
            obj.delete()
            messages.success(request, "Guest deleted.")
        return redirect("customers:list")
    return render(request, "partials/confirm_delete.html", {"title": "Delete guest", "object": obj})
