# Aurevia Grand — Hotel Management System

Aurevia Grand is an original Django 5.2 hotel management system for reservations, rooms, customers, payments, reports, staff roles, and hotel settings.

## Features

- Dashboard with occupancy, arrivals/departures, revenue, balances, and charts
- Room types, rooms, availability, and room-status workflow
- Reservation creation/editing, overlap protection, calendar, check-in/out, cancellation and no-show
- Customer profiles and booking/payment history
- Cash, UPI, card and bank payments, partial payments, refunds, and receipts
- Revenue, occupancy, booking and customer reports with CSV export/print
- Hotel settings, currency/tax settings, notifications, and appearance settings
- Admin / manager / receptionist roles
- Django admin at `/admin/`
- Responsive UI with vendored Bootstrap, Bootstrap Icons, and Chart.js
- PostgreSQL-ready production configuration
- WhiteNoise static-file serving for Render

## Stack

- Python 3.13
- Django 5.2
- PostgreSQL in production / SQLite for local development
- Gunicorn
- WhiteNoise
- Bootstrap 5, Bootstrap Icons, Chart.js

## Run locally

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

Create a local `.env` from `.env.example`, then:

```bash
python manage.py migrate
python manage.py seed_data
python manage.py runserver
```

Open:

```text
http://127.0.0.1:8000/
```

### Local demo accounts

When `DJANGO_DEBUG=True`, `seed_data` uses development fallback passwords if you do not provide seed passwords through environment variables:

| Role | Username | Development password |
|---|---|---|
| Superuser | `admin` | `admin123` |
| Manager | `manager` | `demo1234` |
| Receptionist | `receptionist` | `demo1234` |

**Do not use these development passwords on a public deployment.** Production seeding requires explicit password environment variables.

Django admin:

```text
http://127.0.0.1:8000/admin/
```

## Production / Render deployment

This repository includes:

- `render.yaml` — Render Blueprint
- `build.sh` — dependency installation, Django checks, migrations, static collection, and optional demo seeding
- `.python-version` — pins Python to 3.13.5
- Gunicorn — production WSGI server
- WhiteNoise — production static-file serving

### Recommended Render setup

The included Blueprint creates:

1. A free Python web service
2. A free PostgreSQL database
3. A generated Django secret key
4. HTTPS redirect/security settings
5. Automatic database wiring through `DATABASE_URL`
6. Demo data and initial staff accounts

Connect the GitHub repository to Render as a **Blueprint** and deploy `render.yaml`.

During the first Blueprint setup, Render will ask for these secret values:

```text
SEED_ADMIN_EMAIL
SEED_ADMIN_PASSWORD
SEED_MANAGER_PASSWORD
SEED_RECEPTIONIST_PASSWORD
```

Use strong, unique passwords. These values are **not stored in GitHub**.

After deployment:

```text
https://<your-service>.onrender.com/
```

Django admin:

```text
https://<your-service>.onrender.com/admin/
```

Health check:

```text
https://<your-service>.onrender.com/healthz/
```

### Important free-tier limitation

Render's free web service can sleep after inactivity, and Render's free PostgreSQL database currently expires after 30 days. The free database is suitable for testing/demo use, not permanent hotel production data.

For a real hotel deployment, upgrade the database before the free database expires and use persistent media/object storage for uploaded files.

## Security notes

- Never commit `.env`.
- Never commit `db.sqlite3`.
- Never put production passwords in source code.
- Keep `DJANGO_DEBUG=False` in production.
- Use a strong generated `DJANGO_SECRET_KEY`.
- Set `DJANGO_ALLOWED_HOSTS` when using a custom domain.
- Set `DJANGO_CSRF_TRUSTED_ORIGINS` for custom HTTPS domains when needed.
- Change all demo credentials before using the system with real hotel/customer data.

## Project structure

```text
config/          Django settings, URLs, WSGI/ASGI
core/            Hotel, profiles, settings, seed command
accounts/        Authentication, profile, staff management
dashboard/       Dashboard KPIs and charts
rooms/           Room types, rooms, availability
customers/       Customer management
bookings/        Reservations and booking workflow
payments/        Payments and receipts
reports/         Reports and CSV export
settings_app/    Hotel and application settings
static/          CSS, JS, icons, Bootstrap, Chart.js
templates/       Django templates
build.sh         Render build script
render.yaml      Render Blueprint
```
