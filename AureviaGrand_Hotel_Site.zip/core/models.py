"""Global shared models: Hotel settings, staff profiles and notifications."""
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from django.db import models


class Hotel(models.Model):
    """Singleton record describing the hotel (settings page writes here)."""

    name = models.CharField(max_length=120, default="Aurevia Grand")
    tagline = models.CharField(
        max_length=180, blank=True, default="Where Every Stay Becomes a Story"
    )
    logo = models.ImageField(upload_to="hotel/", blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, default="")
    city = models.CharField(max_length=100, blank=True, default="Gonda")
    state = models.CharField(max_length=100, blank=True, default="Uttar Pradesh")
    country = models.CharField(max_length=100, blank=True, default="India")
    phone = models.CharField(max_length=32, blank=True, default="+918881546450")
    email = models.EmailField(blank=True, default="ratnesht560@gmail.com")
    website = models.URLField(blank=True, default="")
    checkin_time = models.TimeField(default="14:00")
    checkout_time = models.TimeField(default="12:00")
    currency_symbol = models.CharField(max_length=8, default="₹")
    currency_code = models.CharField(max_length=8, blank=True, default="INR")
    tax_percentage = models.DecimalField(
        max_digits=5, decimal_places=2, default=12.00,
        validators=[MinValueValidator(0)],
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Hotel"

    def __str__(self):
        return self.name

    @classmethod
    def get_instance(cls):
        obj, _ = cls.objects.get_or_create(pk=1, defaults={"name": "Aurevia Grand"})
        return obj


class UserProfile(models.Model):
    """Extra per-user data for the staff of the hotel."""

    class Role(models.TextChoices):
        ADMIN = "admin", "Administrator"
        MANAGER = "manager", "Manager"
        RECEPTIONIST = "receptionist", "Receptionist"

    class Theme(models.TextChoices):
        LIGHT = "light", "Light"
        DARK = "dark", "Dark"

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="profile"
    )
    role = models.CharField(max_length=24, choices=Role.choices, default=Role.RECEPTIONIST)
    phone = models.CharField(max_length=32, blank=True, default="")
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)
    theme = models.CharField(max_length=16, choices=Theme.choices, default=Theme.LIGHT)
    primary_color = models.CharField(max_length=7, default="#C9A86A")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Staff profile"

    def __str__(self):
        return f"{self.user.username} ({self.get_role_display()})"

    @classmethod
    def get_or_create_for(cls, user):
        profile, _ = cls.objects.get_or_create(
            user=user, defaults={"role": cls.Role.RECEPTIONIST}
        )
        return profile


class NotificationSetting(models.Model):
    """Per-hotel toggle for in-app notifications."""

    booking_created = models.BooleanField(default=True)
    booking_checked_in = models.BooleanField(default=True)
    booking_checked_out = models.BooleanField(default=True)
    payment_received = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Notification settings"

    def __str__(self):
        return "Notification settings"

    @classmethod
    def get_instance(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


def sync_superuser_profiles():
    """Create a profile for every admin user created via createsuperuser."""
    for user in User.objects.filter(profile__isnull=True):
        UserProfile.objects.create(
            user=user,
            role=UserProfile.Role.ADMIN if user.is_superuser else UserProfile.Role.RECEPTIONIST,
        )


# Keep profile sync automatic on login so legacy/imported users always work.
from django.contrib.auth.signals import user_logged_in  # noqa: E402
from django.dispatch import receiver  # noqa: E402


@receiver(user_logged_in)
def ensure_profile(sender, request, user, **kwargs):
    UserProfile.get_or_create_for(user)
