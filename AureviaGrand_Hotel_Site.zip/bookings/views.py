"""Reservation workflow, check-in/check-out and calendar views."""
import calendar as pycal
from datetime import date, timedelta
from decimal import Decimal

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from bookings.forms import (
    AdditionalChargeForm,
    CheckoutPaymentForm,
    QuickCustomerForm,
    ReservationForm,
)
from bookings.models import AdditionalCharge, Reservation
from bookings.services import month_grid
from core.decorators import admin_or_manager_required, staff_required
from core.models import Hotel
from core.utils import next_booking_id, next_payment_id
from customers.models import Customer
from payments.models import Payment
from rooms.models import Room


def _filter_reservations(request):
    qs = Reservation.objects.select_related("customer", "room", "room__room_type").all()
    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "")
    room = request.GET.get("room", "")
    start = request.GET.get("start", "")
    end = request.GET.get("end", "")

    if q:
        qs = qs.filter(
            Q(booking_id__icontains=q)
            | Q(customer__first_name__icontains=q)
            | Q(customer__last_name__icontains=q)
            | Q(customer__phone__icontains=q)
            | Q(room__room_number__icontains=q)
        )
    if status:
        qs = qs.filter(booking_status=status)
    if room:
        qs = qs.filter(room_id=room)
    if start:
        qs = qs.filter(check_in__gte=start)
    if end:
        qs = qs.filter(check_out__lte=end)

    paginator = Paginator(qs, 15)
    return paginator.get_page(request.GET.get("page")), {
        "q": q, "status": status, "room": room, "start": start, "end": end,
    }


@staff_required
def reservation_list(request):
    page, filters = _filter_reservations(request)
    return render(
        request,
        "bookings/reservation_list.html",
        {
            "reservations": page,
            "filters": filters,
            "statuses": Reservation.BookingStatus.choices,
            "rooms": Room.objects.all(),
        },
    )


def _reservation_form_context(request, form, mode, booking=None):
    return {
        "form": form,
        "mode": mode,
        "booking": booking,
        "rooms": Room.objects.select_related("room_type").filter(is_active=True),
        "customers": Customer.objects.order_by("first_name"),
        "tax": Hotel.get_instance().tax_percentage,
        "quick_form": QuickCustomerForm(),
    }


@admin_or_manager_required
def reservation_create(request):
    if request.method == "POST":
        if request.POST.get("create_customer"):
            quick = QuickCustomerForm(request.POST)
            if quick.is_valid():
                customer = quick.save()
                messages.success(request, f"Guest {customer.full_name} created.")
                return redirect(f"{request.path}?customer={customer.pk}")
            return render(
                request,
                "bookings/reservation_form.html",
                _reservation_form_context(request, ReservationForm(), "create"),
            )
        form = ReservationForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.booking_id = next_booking_id()
            booking.save()
            messages.success(request, f"Reservation {booking.booking_id} created.")
            return redirect("bookings:detail", pk=booking.pk)
        return render(
            request, "bookings/reservation_form.html",
            _reservation_form_context(request, form, "create"),
        )

    form = ReservationForm()
    initial_customer = request.GET.get("customer")
    if initial_customer:
        form.fields["customer"].initial = initial_customer
    return render(
        request, "bookings/reservation_form.html",
        _reservation_form_context(request, form, "create"),
    )


@admin_or_manager_required
def reservation_edit(request, pk):
    booking = get_object_or_404(Reservation, pk=pk)
    form = ReservationForm(instance=booking)
    if request.method == "POST":
        form = ReservationForm(request.POST, instance=booking)
        if form.is_valid():
            saved = form.save()
            messages.success(request, f"Reservation {saved.booking_id} updated.")
            return redirect("bookings:detail", pk=saved.pk)
    return render(
        request, "bookings/reservation_form.html",
        _reservation_form_context(request, form, "edit", booking),
    )


@staff_required
def reservation_detail(request, pk):
    booking = get_object_or_404(
        Reservation.objects.select_related("customer", "room", "room__room_type")
        .prefetch_related("payments", "additional_charges"),
        pk=pk,
    )
    return render(request, "bookings/reservation_detail.html", {"booking": booking})


@admin_or_manager_required
@require_POST
def reservation_action(request, pk, action):
    booking = get_object_or_404(Reservation, pk=pk)
    if action == "confirm":
        booking.booking_status = Reservation.BookingStatus.CONFIRMED
        booking.room.status = booking.room.Status.RESERVED
        booking.room.save(update_fields=["status", "updated_at"])
        booking.save(update_fields=["booking_status", "updated_at"])
        messages.success(request, f"{booking.booking_id} confirmed.")
    elif action == "cancel":
        booking.cancel()
        messages.success(request, f"{booking.booking_id} cancelled.")
    elif action == "no_show":
        booking.mark_no_show()
        messages.success(request, f"{booking.booking_id} marked as no-show.")
    return redirect("bookings:detail", pk=booking.pk)


@staff_required
def checkin_list(request):
    today = date.today()
    due = Reservation.objects.select_related("customer", "room").filter(
        check_in__lte=today,
        booking_status__in=[Reservation.BookingStatus.CONFIRMED, Reservation.BookingStatus.PENDING],
    ).order_by("check_in")
    checked_in = Reservation.objects.select_related("customer", "room").filter(
        booking_status=Reservation.BookingStatus.CHECKED_IN
    ).order_by("-checkin_at")
    return render(request, "bookings/checkin.html", {"due": due, "checked_in": checked_in, "today": today})


@admin_or_manager_required
@require_POST
def checkin_confirm(request, pk):
    booking = get_object_or_404(Reservation, pk=pk)
    if booking.booking_status not in (
        Reservation.BookingStatus.CONFIRMED,
        Reservation.BookingStatus.PENDING,
    ):
        messages.error(request, "Only confirmed or pending reservations can be checked in.")
        return redirect("bookings:checkin")
    booking.check_in_now()
    messages.success(request, f"{booking.booking_id} checked in — room {booking.room} is now occupied.")
    return redirect("bookings:checkin")


@staff_required
def checkout_list(request):
    today = date.today()
    active = Reservation.objects.select_related("customer", "room").filter(
        booking_status=Reservation.BookingStatus.CHECKED_IN
    ).order_by("-checkin_at")
    return render(request, "bookings/checkout.html", {"active": active, "today": today})


@staff_required
def checkout_detail(request, pk):
    booking = get_object_or_404(
        Reservation.objects.select_related("customer", "room", "room__room_type")
        .prefetch_related("payments", "additional_charges"),
        pk=pk,
    )
    if booking.booking_status != Reservation.BookingStatus.CHECKED_IN:
        messages.warning(request, "This reservation is not currently checked in.")
        return redirect("bookings:checkout")

    charge_form = AdditionalChargeForm()
    payment_form = CheckoutPaymentForm()
    if request.method == "POST":
        if request.POST.get("add_charge"):
            charge_form = AdditionalChargeForm(request.POST)
            if charge_form.is_valid():
                charge = charge_form.save(commit=False)
                charge.reservation = booking
                charge.save()
                booking.sync_payment_status()
                booking.save()
                messages.success(request, "Additional charge added.")
                return redirect("bookings:checkout_detail", pk=booking.pk)
        elif request.POST.get("record_payment"):
            payment_form = CheckoutPaymentForm(request.POST)
            if payment_form.is_valid():
                Payment.objects.create(
                    payment_id=next_payment_id(),
                    reservation=booking,
                    customer=booking.customer,
                    amount=payment_form.cleaned_data["amount"],
                    method=payment_form.cleaned_data["method"],
                    reference=payment_form.cleaned_data.get("reference", ""),
                )
                booking.sync_payment_status()
                booking.save()
                messages.success(request, "Payment recorded.")
                return redirect("bookings:checkout_detail", pk=booking.pk)
    return render(
        request,
        "bookings/checkout_detail.html",
        {
            "booking": booking,
            "charge_form": charge_form,
            "payment_form": payment_form,
            "balance": booking.balance_due,
        },
    )


@admin_or_manager_required
@require_POST
def checkout_confirm(request, pk):
    booking = get_object_or_404(Reservation, pk=pk)
    if booking.booking_status != Reservation.BookingStatus.CHECKED_IN:
        messages.error(request, "Only checked-in reservations can be checked out.")
        return redirect("bookings:checkout")
    booking.check_out_now()
    messages.success(request, f"{booking.booking_id} checked out — room {booking.room} sent for cleaning.")
    return redirect("bookings:checkout")


@staff_required
def calendar_view(request):
    today = date.today()
    try:
        year = int(request.GET.get("year", today.year))
        month = int(request.GET.get("month", today.month))
    except ValueError:
        year, month = today.year, today.month

    if not 1 <= month <= 12:
        month = today.month
    if not 1900 <= year <= 2100:
        year = today.year

    grid, total_rooms = month_grid(year, month)
    selected = request.GET.get("day", "")
    day_reservations = []
    if selected:
        try:
            sel_date = date.fromisoformat(selected)
        except ValueError:
            sel_date = None
        if sel_date:
            day_reservations = (
                Reservation.objects.select_related("customer", "room")
                .filter(
                    booking_status__in=Reservation.ACTIVE_STATUSES,
                    check_in__lt=sel_date + timedelta(days=1),
                    check_out__gt=sel_date,
                )
                .order_by("check_in")
            )

    first_weekday = pycal.weekday(year, month, 1)
    weeks = [[]]
    for _ in range(first_weekday):
        weeks[0].append(None)
    for entry in grid:
        if len(weeks[-1]) == 7:
            weeks.append([])
        weeks[-1].append(entry)
    while len(weeks[-1]) < 7:
        weeks[-1].append(None)

    prev = (year - 1, 12) if month == 1 else (year, month - 1)
    nxt = (year + 1, 1) if month == 12 else (year, month + 1)
    return render(
        request,
        "bookings/calendar.html",
        {
            "weeks": weeks,
            "year": year,
            "month": month,
            "month_name": pycal.month_name[month],
            "today": today,
            "selected": selected,
            "day_reservations": day_reservations,
            "total_rooms": total_rooms,
            "prev": prev,
            "next": nxt,
        },
    )
