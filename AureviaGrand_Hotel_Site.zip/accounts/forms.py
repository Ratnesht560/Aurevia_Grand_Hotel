"""Authentication and staff management forms."""
from django import forms
from django.contrib.auth.models import User

from core.models import UserProfile


class RememberMeAuthenticationForm(forms.Form):
    username = forms.CharField(
        label="Username or email",
        max_length=150,
        widget=forms.TextInput(
            attrs={
                "class": "form-control",
                "placeholder": "Username or email",
                "autocomplete": "username",
                "autofocus": True,
            }
        ),
    )
    password = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control",
                "placeholder": "Password",
                "autocomplete": "current-password",
            }
        ),
    )
    remember = forms.BooleanField(required=False, label="Remember me")


class ProfileForm(forms.ModelForm):
    username = forms.CharField(label="Username", disabled=True, required=False)
    email = forms.EmailField(label="Email")
    first_name = forms.CharField(label="First name", required=False)
    last_name = forms.CharField(label="Last name", required=False)

    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email"]


class ProfileDetailForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ["phone", "avatar"]
        widgets = {
            "phone": forms.TextInput(attrs={"class": "form-control", "placeholder": "+91..."}),
            "avatar": forms.FileInput(attrs={"class": "form-control"}),
        }


class ChangePasswordForm(forms.Form):
    current_password = forms.CharField(
        label="Current password",
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "current-password"}),
    )
    new_password = forms.CharField(
        label="New password",
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
    )
    confirm_password = forms.CharField(
        label="Confirm new password",
        widget=forms.PasswordInput(attrs={"class": "form-control", "autocomplete": "new-password"}),
    )

    def clean(self):
        cleaned = super().clean()
        new = cleaned.get("new_password")
        confirm = cleaned.get("confirm_password")
        if new and confirm and new != confirm:
            self.add_error("confirm_password", "The two passwords do not match.")
        if new and len(new) < 8:
            self.add_error("new_password", "Password must be at least 8 characters.")
        return cleaned


class StaffUserForm(forms.ModelForm):
    role = forms.ChoiceField(choices=UserProfile.Role.choices, label="Role")

    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email", "is_active"]
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "first_name": forms.TextInput(attrs={"class": "form-control"}),
            "last_name": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }


class StaffCreateForm(StaffUserForm):
    password = forms.CharField(
        label="Temporary password",
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
        help_text="Min 8 characters.",
    )

    def clean_username(self):
        username = self.cleaned_data.get("username")
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("A user with this username already exists.")
        return username

    def clean_password(self):
        password = self.cleaned_data.get("password")
        if password and len(password) < 8:
            raise forms.ValidationError("Password must be at least 8 characters.")
        return password
