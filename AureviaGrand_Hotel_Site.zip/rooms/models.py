"""Room types and physical rooms."""
from django.core.validators import MinValueValidator
from django.db import models


class RoomType(models.Model):
    name = models.CharField(max_length=80, unique=True)
    description = models.TextField(blank=True, default="")
    max_occupancy = models.PositiveIntegerField(default=2, validators=[MinValueValidator(1)])
    base_price = models.DecimalField(
        max_digits=10, decimal_places=2, validators=[MinValueValidator(0)]
    )
    beds = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    amenities = models.TextField(
        blank=True, default="",
        help_text="Comma separated list, e.g. Wi-Fi, Air conditioning, TV",
    )
    image = models.ImageField(upload_to="room_types/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    @property
    def amenity_list(self):
        return [a.strip() for a in (self.amenities or "").split(",") if a.strip()]

    @property
    def room_count(self):
        return self.rooms.filter(is_active=True).count()


class Room(models.Model):
    class Status(models.TextChoices):
        AVAILABLE = "available", "Available"
        OCCUPIED = "occupied", "Occupied"
        RESERVED = "reserved", "Reserved"
        CLEANING = "cleaning", "Cleaning"
        MAINTENANCE = "maintenance", "Maintenance"
        OUT_OF_SERVICE = "out_of_service", "Out of Service"

    room_number = models.CharField(max_length=16, unique=True)
    room_type = models.ForeignKey(
        RoomType, on_delete=models.PROTECT, related_name="rooms"
    )
    floor = models.PositiveIntegerField(default=1, validators=[MinValueValidator(0)])
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.AVAILABLE)
    price_override = models.DecimalField(
        max_digits=10, decimal_places=2, blank=True, null=True,
        validators=[MinValueValidator(0)],
        help_text="Leave blank to use the room type base price.",
    )
    description = models.TextField(blank=True, default="")
    amenities = models.TextField(blank=True, default="")
    image = models.ImageField(upload_to="rooms/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["floor", "room_number"]

    def __str__(self):
        return self.room_number

    @property
    def rate(self):
        return self.price_override if self.price_override else self.room_type.base_price

    @property
    def amenity_list(self):
        return [a.strip() for a in (self.amenities or "").split(",") if a.strip()]
