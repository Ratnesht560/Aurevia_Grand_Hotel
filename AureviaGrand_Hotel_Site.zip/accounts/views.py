"""Authentication, profile and staff management views."""
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.forms import (
    ProfileDetailForm,
    ProfileForm,
    RememberMeAuthenticationForm,
    StaffCreateForm,
    StaffUserForm,
)
from core.decorators import admin_or_manager_required, staff_required
from core.models import UserProfile

SESSION_30_DAYS = 30 * 24 * 60 * 60


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard:index")
    form = RememberMeAuthenticationForm()
    if request.method == "POST":
        form = RememberMeAuthenticationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(request, username=username, password=password)
            if user is None and "@" in username:
                user_qs = User.objects.filter(email__iexact=username)
                if user_qs.exists():
                    user = authenticate(
                        request, username=user_qs.first().username, password=password
                    )
            if user is not None and user.is_active:
                login(request, user)
                if form.cleaned_data.get("remember"):
                    request.session.set_expiry(SESSION_30_DAYS)
                else:
                    request.session.set_expiry(0)
                messages.success(request, f"Welcome back, {user.first_name or user.username}.")
                return redirect(request.GET.get("next") or "dashboard:index")
            form.add_error(None, "Invalid username or password.")
    return render(request, "registration/login.html", {"form": form})


def logout_view(request):
    logout(request)
    messages.success(request, "You have been signed out.")
    return redirect("accounts:login")


@staff_required
def profile_view(request):
    profile = UserProfile.get_or_create_for(request.user)
    user_form = ProfileForm(instance=request.user)
    detail_form = ProfileDetailForm(instance=profile)
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "profile":
            user_form = ProfileForm(request.POST, instance=request.user)
            detail_form = ProfileDetailForm(request.POST, request.FILES, instance=profile)
            if user_form.is_valid() and detail_form.is_valid():
                user = user_form.save()
                detail = detail_form.save(commit=False)
                detail.user = request.user
                detail.save()
                messages.success(request, "Profile updated.")
                return redirect("accounts:profile")
        elif action == "password":
            pwd_form = PasswordChangeForm(request.user, request.POST)
            if pwd_form.is_valid():
                user = pwd_form.save()
                update_session_auth_hash(request, user)
                messages.success(request, "Password changed successfully.")
                return redirect("accounts:profile")
            return render(
                request,
                "accounts/profile.html",
                {
                    "user_form": user_form,
                    "detail_form": detail_form,
                    "pwd_form": pwd_form,
                },
            )
    return render(
        request,
        "accounts/profile.html",
        {
            "user_form": user_form,
            "detail_form": detail_form,
            "pwd_form": PasswordChangeForm(request.user),
        },
    )


@admin_or_manager_required
def staff_list(request):
    from django.db.models import Q

    qs = User.objects.select_related("profile").order_by("-is_superuser", "username")
    query = request.GET.get("q", "").strip()
    if query:
        qs = qs.filter(
            Q(username__icontains=query)
            | Q(email__icontains=query)
            | Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
        )
    return render(request, "staff/list.html", {"staff": qs, "query": query})


@admin_or_manager_required
def staff_create(request):
    form = StaffCreateForm()
    if request.method == "POST":
        form = StaffCreateForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data["password"])
            user.is_staff = True
            user.save()
            UserProfile.objects.create(user=user, role=form.cleaned_data["role"])
            messages.success(request, f"Staff account {user.username} created.")
            return redirect("accounts:staff_list")
    return render(request, "staff/form.html", {"form": form, "mode": "create"})


@admin_or_manager_required
def staff_edit(request, pk):
    user = get_object_or_404(User, pk=pk)
    profile = UserProfile.get_or_create_for(user)
    form = StaffUserForm(instance=user)
    if request.method == "POST":
        form = StaffUserForm(request.POST, instance=user)
        if form.is_valid():
            user = form.save()
            profile.role = form.cleaned_data["role"]
            profile.save()
            messages.success(request, f"Staff account {user.username} updated.")
            return redirect("accounts:staff_list")
    return render(request, "staff/form.html", {"form": form, "profile": profile, "mode": "edit"})


@admin_or_manager_required
@require_POST
def staff_toggle(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user == request.user:
        messages.error(request, "You cannot deactivate your own account.")
        return redirect("accounts:staff_list")
    user.is_active = not user.is_active
    user.save()
    state = "activated" if user.is_active else "deactivated"
    messages.success(request, f"{user.username} {state}.")
    return redirect("accounts:staff_list")
