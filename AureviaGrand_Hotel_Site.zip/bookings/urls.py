from django.urls import path

from bookings import views

app_name = "bookings"

urlpatterns = [
    path("", views.reservation_list, name="list"),
    path("new/", views.reservation_create, name="create"),
    path("calendar/", views.calendar_view, name="calendar"),
    path("<int:pk>/", views.reservation_detail, name="detail"),
    path("<int:pk>/edit/", views.reservation_edit, name="edit"),
    path("<int:pk>/action/<str:action>/", views.reservation_action, name="action"),
    path("checkin/", views.checkin_list, name="checkin"),
    path("checkin/<int:pk>/confirm/", views.checkin_confirm, name="checkin_confirm"),
    path("checkout/", views.checkout_list, name="checkout"),
    path("checkout/<int:pk>/", views.checkout_detail, name="checkout_detail"),
    path("checkout/<int:pk>/confirm/", views.checkout_confirm, name="checkout_confirm"),
]
