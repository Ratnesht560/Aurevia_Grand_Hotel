"""Small helpers shared across apps."""
import random
import string
from datetime import date, timedelta

from django.db.models import Sum
from django.utils import timezone


def brand_initials(name):
    parts = [p for p in name.split() if p]
    if not parts:
        return "AG"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[1][0]).upper()


def next_booking_id(now=None):
    """Generate a booking reference such as AG-17082026-7K2Q."""
    now = now or timezone.localdate()
    seq = "".join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"AG-{now:%d%m%Y}-{seq}"


def next_payment_id():
    seq = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"PAY-{seq}"


def mask_id(value):
    """Mask a sensitive ID number, e.g. 1234 5678 -> •••• ••••."""
    value = (value or "").strip()
    if len(value) <= 4:
        return value
    return "•" * (len(value) - 4) + value[-4:]


def money(value, symbol="₹", decimals=2):
    try:
        num = float(value or 0)
    except (TypeError, ValueError):
        num = 0.0
    return f"{symbol}{num:,.{decimals}f}"


def nights_between(start, end):
    delta = (end - start).days
    return delta if delta > 0 else 0


def serialize_chart_date(d, fmt="%d %b"):
    return d.strftime(fmt)


def last_n_days(n):
    today = date.today()
    return [today - timedelta(days=i) for i in range(n - 1, -1, -1)]


def aggregate_sum(queryset, field):
    return queryset.aggregate(total=Sum(field))["total"] or 0
