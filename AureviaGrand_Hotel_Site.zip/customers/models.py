"""Hotel guests."""
from django.db import models

from core.utils import mask_id


class Customer(models.Model):
    class IdType(models.TextChoices):
        PASSPORT = "passport", "Passport"
        AADHAAR = "aadhaar", "Aadhaar"
        PAN = "pan", "PAN"
        DRIVING_LICENSE = "driving_license", "Driving License"
        OTHER = "other", "Other"

    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80, blank=True, default="")
    email = models.EmailField(blank=True, default="")
    phone = models.CharField(max_length=32)
    address = models.CharField(max_length=255, blank=True, default="")
    city = models.CharField(max_length=100, blank=True, default="")
    state = models.CharField(max_length=100, blank=True, default="")
    country = models.CharField(max_length=100, blank=True, default="India")
    id_type = models.CharField(max_length=32, choices=IdType.choices, blank=True, default="")
    id_number = models.CharField(max_length=64, blank=True, default="")
    date_of_birth = models.DateField(blank=True, null=True)
    notes = models.TextField(blank=True, default="")
    photo = models.ImageField(upload_to="customers/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["first_name", "last_name"]
        indexes = [
            models.Index(fields=["email"]),
            models.Index(fields=["phone"]),
        ]

    def __str__(self):
        return self.full_name

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def masked_id_number(self):
        return mask_id(self.id_number)

    @property
    def booking_count(self):
        return self.reservations.count()
