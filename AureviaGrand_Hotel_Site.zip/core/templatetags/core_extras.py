from django import template

from core.utils import mask_id, money

register = template.Library()


@register.filter(name="money")
def money_filter(value, symbol="₹"):
    return money(value, symbol)


@register.filter(name="mask_id")
def mask_id_filter(value):
    return mask_id(value)


@register.filter(name="status_badge")
def status_badge(value, group="default"):
    """Map a status string to a Bootstrap-ish badge class."""
    classes = {
        "available": "success",
        "occupied": "danger",
        "reserved": "primary",
        "cleaning": "warning",
        "maintenance": "secondary",
        "out_of_service": "dark",
        "pending": "warning",
        "confirmed": "primary",
        "checked_in": "info",
        "checked_out": "success",
        "cancelled": "secondary",
        "no_show": "danger",
        "unpaid": "danger",
        "partially_paid": "warning",
        "paid": "success",
        "refunded": "secondary",
        "active": "success",
        "inactive": "secondary",
        "cash": "success",
        "upi": "info",
        "credit_card": "primary",
        "debit_card": "warning",
        "bank_transfer": "secondary",
        "other": "dark",
        "admin": "primary",
        "manager": "info",
        "receptionist": "secondary",
    }
    key = str(value or "").lower()
    return f"badge-{classes.get(key, 'secondary')}"


@register.filter(name="humanize_status")
def humanize_status(value):
    return str(value).replace("_", " ").title()


@register.filter(name="avatar_color")
def avatar_color(value):
    """Deterministic pastel color from a string for initials avatars."""
    palette = ["#C9A86A", "#16866A", "#0B1F33", "#8A6D3B", "#2C7DA0", "#7B4B94"]
    if not value:
        return palette[0]
    return palette[sum(ord(c) for c in value) % len(palette)]
