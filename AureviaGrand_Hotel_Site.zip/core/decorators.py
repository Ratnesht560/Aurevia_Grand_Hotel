"""Permission helpers and reusable guards."""
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.decorators import method_decorator

from core.models import UserProfile


def staff_required(view_func):
    """Allow access only to logged-in staff members (any role)."""

    @login_required(login_url="accounts:login")
    def _wrapped(request, *args, **kwargs):
        UserProfile.get_or_create_for(request.user)
        return view_func(request, *args, **kwargs)

    return _wrapped


def admin_or_manager_required(view_func):
    """Restrict a view to admin or manager roles."""

    @staff_required
    def _wrapped(request, *args, **kwargs):
        profile = UserProfile.get_or_create_for(request.user)
        if profile.role not in (UserProfile.Role.ADMIN, UserProfile.Role.MANAGER):
            raise PermissionDenied("You need manager privileges to perform this action.")
        return view_func(request, *args, **kwargs)

    return _wrapped


class StaffRequiredMixin:
    """Mixin to apply login/staff checks on class-based views."""

    @method_decorator(staff_required)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)


def is_staff(user):
    return user.is_authenticated
