from django.contrib import admin

from rooms.models import Room, RoomType


@admin.register(RoomType)
class RoomTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "base_price", "max_occupancy", "beds", "is_active", "room_count")
    list_filter = ("is_active",)
    search_fields = ("name", "description")
    readonly_fields = ("created_at", "updated_at")
    ordering = ("name",)


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ("room_number", "room_type", "floor", "status", "rate", "is_active")
    list_filter = ("status", "room_type", "floor", "is_active")
    search_fields = ("room_number", "room_type__name")
    autocomplete_fields = ("room_type",)
    list_select_related = ("room_type",)
    readonly_fields = ("created_at", "updated_at")
