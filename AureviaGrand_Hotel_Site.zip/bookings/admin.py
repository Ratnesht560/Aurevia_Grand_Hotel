from django.contrib import admin

from bookings.models import AdditionalCharge, Reservation


class AdditionalChargeInline(admin.TabularInline):
    model = AdditionalCharge
    extra = 0


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = (
        "booking_id", "customer", "room", "check_in", "check_out",
        "nights", "total", "payment_status", "booking_status",
    )
    list_filter = ("booking_status", "payment_status", "check_in", "check_out")
    search_fields = ("booking_id", "customer__first_name", "customer__last_name", "customer__phone")
    list_select_related = ("customer", "room")
    readonly_fields = (
        "booking_id", "nights", "tax_amount", "total", "amount_paid",
        "balance_due", "created_at", "updated_at", "checkin_at", "checkout_at",
    )
    fieldsets = (
        (None, {"fields": ("booking_id", "customer", "room")}),
        ("Stay", {"fields": ("check_in", "check_out", "adults", "children", "nights")}),
        ("Billing", {
            "fields": ("rate_per_night", "tax_amount", "discount", "total",
                       "amount_paid", "balance_due"),
        }),
        ("Status", {"fields": ("booking_status", "payment_status", "special_requests")}),
        ("Timestamps", {"fields": ("checkin_at", "checkout_at", "created_at", "updated_at")}),
    )
    date_hierarchy = "check_in"
    autocomplete_fields = ("customer", "room")
    inlines = (AdditionalChargeInline,)

    def has_add_permission(self, request):
        return True


@admin.register(AdditionalCharge)
class AdditionalChargeAdmin(admin.ModelAdmin):
    list_display = ("reservation", "description", "amount", "created_at")
    search_fields = ("reservation__booking_id", "description")
