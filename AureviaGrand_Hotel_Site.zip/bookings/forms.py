"""Forms for reservations and additional charges."""
from decimal import Decimal

from django import forms

from bookings.models import AdditionalCharge, Reservation
from bookings.services import overlapping_reservations
from core.models import Hotel
from customers.models import Customer
from payments.models import Payment
from rooms.models import Room


class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = [
            "customer", "room", "check_in", "check_out", "adults", "children",
            "rate_per_night", "discount", "special_requests",
            "booking_status", "payment_status",
        ]
        widgets = {
            "customer": forms.Select(attrs={"class": "form-select", "id": "id_customer"}),
            "room": forms.Select(attrs={"class": "form-select"}),
            "check_in": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "check_out": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "adults": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "children": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "rate_per_night": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01", "id": "id_rate"}),
            "discount": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01", "id": "id_discount"}),
            "special_requests": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "booking_status": forms.Select(attrs={"class": "form-select"}),
            "payment_status": forms.Select(attrs={"class": "form-select"}),
        }

    def clean(self):
        cleaned = super().clean()
        check_in = cleaned.get("check_in")
        check_out = cleaned.get("check_out")
        room = cleaned.get("room")
        rate = cleaned.get("rate_per_night")

        if check_in and check_out and check_out <= check_in:
            self.add_error("check_out", "Check-out must be after check-in.")

        if room and check_in and check_out and check_out > check_in:
            overlaps = overlapping_reservations(
                room, check_in, check_out, exclude_pk=self.instance.pk
            )
            if overlaps.exists():
                clash = overlaps.first()
                self.add_error(
                    "room",
                    f"{room} is already reserved from {clash.check_in} to {clash.check_out} "
                    f"({clash.booking_id}).",
                )

        if rate is not None and rate <= 0:
            self.add_error("rate_per_night", "Rate must be greater than zero.")

        if cleaned.get("discount") and cleaned.get("discount") < 0:
            self.add_error("discount", "Discount cannot be negative.")
        return cleaned

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.recalculate()
        if commit:
            instance.save()
        return instance


class QuickCustomerForm(forms.ModelForm):
    """Inline guest creation used from the reservation page."""

    class Meta:
        model = Customer
        fields = ["first_name", "last_name", "phone", "email"]
        widgets = {
            "first_name": forms.TextInput(attrs={"class": "form-control", "placeholder": "First name", "required": True}),
            "last_name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Last name"}),
            "phone": forms.TextInput(attrs={"class": "form-control", "placeholder": "+91..."}),
            "email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "name@email.com"}),
        }

    def clean_phone(self):
        phone = self.cleaned_data.get("phone", "").strip()
        if not phone:
            raise forms.ValidationError("A phone number is required.")
        return phone


class AdditionalChargeForm(forms.ModelForm):
    class Meta:
        model = AdditionalCharge
        fields = ["description", "amount"]
        widgets = {
            "description": forms.TextInput(attrs={"class": "form-control", "placeholder": "e.g. Minibar"}),
            "amount": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01"}),
        }


class CheckoutPaymentForm(forms.Form):
    amount = forms.DecimalField(
        label="Amount paid now",
        min_value=Decimal("0.01"),
        widget=forms.NumberInput(attrs={"class": "form-control", "min": "0.01", "step": "0.01"}),
    )
    method = forms.ChoiceField(
        choices=Payment.Method.choices,
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    reference = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Transaction reference"}),
    )
