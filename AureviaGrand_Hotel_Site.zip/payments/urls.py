from django.urls import path

from payments import views

app_name = "payments"

urlpatterns = [
    path("", views.payment_list, name="list"),
    path("new/", views.payment_create, name="create"),
    path("<int:pk>/receipt/", views.payment_receipt, name="receipt"),
]
