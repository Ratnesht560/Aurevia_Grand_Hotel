from django.contrib import admin

from core.models import Hotel, NotificationSetting, UserProfile


@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    fieldsets = (
        ("Brand", {"fields": ("name", "tagline", "logo")}),
        ("Contact", {"fields": ("address", "city", "state", "country", "phone", "email", "website")}),
        ("Operations", {"fields": ("checkin_time", "checkout_time")}),
        ("Billing", {"fields": ("currency_symbol", "currency_code", "tax_percentage")}),
    )
    readonly_fields = ("updated_at",)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "role", "theme", "phone")
    list_filter = ("role", "theme")
    search_fields = ("user__username", "user__email", "phone")


@admin.register(NotificationSetting)
class NotificationSettingAdmin(admin.ModelAdmin):
    list_display = ("booking_created", "booking_checked_in", "booking_checked_out", "payment_received")
