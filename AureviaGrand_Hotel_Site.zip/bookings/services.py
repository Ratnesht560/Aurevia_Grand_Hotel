"""Business logic for reservations: pricing and room availability."""
from datetime import date, timedelta
from decimal import Decimal

from bookings.models import Reservation
from core.models import Hotel
from rooms.models import Room


def compute_price(rate, check_in, check_out, discount=Decimal("0.00"), tax_percentage=None):
    """Return a dict of nights, tax and total for a stay."""
    rate = Decimal(rate or 0)
    discount = Decimal(discount or 0)
    nights = (check_out - check_in).days
    if nights < 1:
        nights = 0
    tax_pct = Decimal(
        tax_percentage if tax_percentage is not None else Hotel.get_instance().tax_percentage
    )
    subtotal = rate * nights
    tax_amount = (subtotal * tax_pct / Decimal(100)).quantize(Decimal("0.01"))
    total = (subtotal + tax_amount - discount).quantize(Decimal("0.01"))
    return {
        "nights": nights,
        "subtotal": subtotal,
        "tax_amount": tax_amount,
        "total": total,
    }


def overlapping_reservations(room, check_in, check_out, exclude_pk=None):
    """Active reservations for a room that collide with the given stay."""
    qs = Reservation.objects.filter(
        room=room,
        booking_status__in=Reservation.ACTIVE_STATUSES,
        check_in__lt=check_out,
        check_out__gt=check_in,
    )
    if exclude_pk:
        qs = qs.exclude(pk=exclude_pk)
    return qs


def available_rooms(check_in, check_out):
    """Rooms free for a whole stay (active reservations with no collision)."""
    collisions = (
        Reservation.objects.filter(
            booking_status__in=Reservation.ACTIVE_STATUSES,
            check_in__lt=check_out,
            check_out__gt=check_in,
        )
        .values_list("room_id", flat=True)
        .distinct()
    )
    return (
        Room.objects.filter(is_active=True, status__in=[Room.Status.AVAILABLE, Room.Status.RESERVED])
        .exclude(id__in=collisions)
        .select_related("room_type")
    )


def month_grid(year, month):
    """Occupancy summary per day for a calendar view."""
    first = date(year, month, 1)
    if month == 12:
        nxt = date(year + 1, 1, 1)
    else:
        nxt = date(year, month + 1, 1)
    days = (nxt - first).days

    reservations = list(
        Reservation.objects.filter(
            booking_status__in=Reservation.ACTIVE_STATUSES,
            check_in__lt=nxt,
            check_out__gt=first,
        )
    )
    total_rooms = Room.objects.filter(is_active=True).count()

    grid = []
    for day_offset in range(days):
        d = first + timedelta(days=day_offset)
        arrivals = sum(1 for r in reservations if r.check_in == d)
        departures = sum(1 for r in reservations if r.check_out == d)
        staying = sum(
            1 for r in reservations if r.check_in <= d and r.check_out > d
        )
        grid.append(
            {
                "date": d,
                "day": d.day,
                "arrivals": arrivals,
                "departures": departures,
                "occupied": staying,
                "percent": round(staying * 100 / total_rooms) if total_rooms else 0,
            }
        )
    return grid, total_rooms
