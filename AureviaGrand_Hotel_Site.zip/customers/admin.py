from django.contrib import admin

from customers.models import Customer


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "phone", "city", "country", "id_type", "created_at")
    list_filter = ("country", "id_type")
    search_fields = ("first_name", "last_name", "email", "phone")
    readonly_fields = ("created_at", "updated_at")
    date_hierarchy = "created_at"
    fieldsets = (
        ("Identity", {"fields": ("first_name", "last_name", "email", "phone", "date_of_birth", "photo")}),
        ("Address", {"fields": ("address", "city", "state", "country")}),
        ("ID Proof", {"fields": ("id_type", "id_number")}),
        ("Notes", {"fields": ("notes",)}),
    )
