"""Reservations and additional charges."""
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models, transaction
from django.utils import timezone

from core.models import Hotel


class Reservation(models.Model):
    class BookingStatus(models.TextChoices):
        PENDING = "pending", "Pending"
        CONFIRMED = "confirmed", "Confirmed"
        CHECKED_IN = "checked_in", "Checked In"
        CHECKED_OUT = "checked_out", "Checked Out"
        CANCELLED = "cancelled", "Cancelled"
        NO_SHOW = "no_show", "No Show"

    class PaymentStatus(models.TextChoices):
        UNPAID = "unpaid", "Unpaid"
        PARTIAL = "partially_paid", "Partially Paid"
        PAID = "paid", "Paid"
        REFUNDED = "refunded", "Refunded"

    ACTIVE_STATUSES = (BookingStatus.PENDING, BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN)

    booking_id = models.CharField(max_length=32, unique=True, editable=False)
    customer = models.ForeignKey(
        "customers.Customer", on_delete=models.PROTECT, related_name="reservations"
    )
    room = models.ForeignKey(
        "rooms.Room", on_delete=models.PROTECT, related_name="reservations"
    )
    check_in = models.DateField()
    check_out = models.DateField()
    adults = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    children = models.PositiveIntegerField(default=0, validators=[MinValueValidator(0)])
    rate_per_night = models.DecimalField(
        max_digits=10, decimal_places=2, validators=[MinValueValidator(0)]
    )
    nights = models.PositiveIntegerField(default=1)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    discount = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        validators=[MinValueValidator(0)],
    )
    total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    payment_status = models.CharField(
        max_length=24, choices=PaymentStatus.choices, default=PaymentStatus.UNPAID
    )
    booking_status = models.CharField(
        max_length=24, choices=BookingStatus.choices, default=BookingStatus.PENDING
    )
    special_requests = models.TextField(blank=True, default="")
    checkin_at = models.DateTimeField(blank=True, null=True)
    checkout_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-check_in", "-created_at"]
        indexes = [
            models.Index(fields=["check_in", "check_out"]),
            models.Index(fields=["booking_status"]),
            models.Index(fields=["payment_status"]),
        ]

    def __str__(self):
        return self.booking_id

    @property
    def subtotal(self):
        return Decimal(self.rate_per_night) * self.nights

    @property
    def amount_paid(self):
        total = self.payments.aggregate(paid=models.Sum("amount"))["paid"] or Decimal("0")
        return Decimal(total)

    @property
    def balance_due(self):
        return self.total + self.extra_charges_total - self.amount_paid

    @property
    def extra_charges_total(self):
        total = self.additional_charges.aggregate(t=models.Sum("amount"))["t"] or Decimal("0")
        return Decimal(total)

    @property
    def grand_total(self):
        return self.total + self.extra_charges_total

    @property
    def is_active(self):
        return self.booking_status in self.ACTIVE_STATUSES

    def recalculate(self, tax_percentage=None):
        """Recompute nights, tax and total from the persisted rates."""
        nights = (self.check_out - self.check_in).days
        if nights < 1:
            nights = 1
        self.nights = nights
        tax_pct = Decimal(
            tax_percentage if tax_percentage is not None else Hotel.get_instance().tax_percentage
        )
        subtotal = Decimal(self.rate_per_night) * nights
        self.tax_amount = (subtotal * tax_pct / Decimal(100)).quantize(Decimal("0.01"))
        self.total = (subtotal + self.tax_amount - Decimal(self.discount)).quantize(
            Decimal("0.01")
        )

    def has_overlap(self):
        """Return True when another active reservation occupies the same room."""
        return (
            type(self)
            .objects.filter(
                room=self.room,
                booking_status__in=self.ACTIVE_STATUSES,
                check_in__lt=self.check_out,
                check_out__gt=self.check_in,
            )
            .exclude(pk=self.pk)
            .exists()
        )

    def sync_payment_status(self):
        """Derive payment status from the recorded payments."""
        paid = self.amount_paid
        if paid <= 0:
            self.payment_status = self.PaymentStatus.UNPAID
        elif paid < self.total + self.extra_charges_total:
            self.payment_status = self.PaymentStatus.PARTIAL
        else:
            self.payment_status = self.PaymentStatus.PAID

    def check_in_now(self):
        with transaction.atomic():
            self.booking_status = self.BookingStatus.CHECKED_IN
            self.checkin_at = timezone.now()
            self.room.status = self.room.Status.OCCUPIED
            self.room.save(update_fields=["status", "updated_at"])
            self.save(update_fields=["booking_status", "checkin_at", "updated_at"])

    def check_out_now(self):
        with transaction.atomic():
            self.booking_status = self.BookingStatus.CHECKED_OUT
            self.checkout_at = timezone.now()
            self.sync_payment_status()
            self.room.status = self.room.Status.CLEANING
            self.room.save(update_fields=["status", "updated_at"])
            self.save(
                update_fields=[
                    "booking_status", "checkout_at", "payment_status", "updated_at",
                ]
            )

    def cancel(self):
        with transaction.atomic():
            self.booking_status = self.BookingStatus.CANCELLED
            self.room.status = self.room.Status.AVAILABLE
            self.room.save(update_fields=["status", "updated_at"])
            self.save(update_fields=["booking_status", "updated_at"])

    def mark_no_show(self):
        with transaction.atomic():
            self.booking_status = self.BookingStatus.NO_SHOW
            self.room.status = self.room.Status.AVAILABLE
            self.room.save(update_fields=["status", "updated_at"])
            self.save(update_fields=["booking_status", "updated_at"])


class AdditionalCharge(models.Model):
    reservation = models.ForeignKey(
        Reservation, on_delete=models.CASCADE, related_name="additional_charges"
    )
    description = models.CharField(max_length=120)
    amount = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.description} ({self.amount})"
