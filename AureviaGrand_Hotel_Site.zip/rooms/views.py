"""Room type and room management views."""
from datetime import date

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render

from bookings.models import Reservation
from core.decorators import admin_or_manager_required, staff_required
from rooms.forms import RoomForm, RoomTypeForm
from rooms.models import Room, RoomType


@staff_required
def roomtype_list(request):
    types = (
        RoomType.objects.annotate(
            rooms_count=Count("rooms", filter=Q(rooms__is_active=True))
        ).order_by("name")
    )
    return render(request, "rooms/roomtype_list.html", {"types": types})


@admin_or_manager_required
def roomtype_create(request):
    form = RoomTypeForm()
    if request.method == "POST":
        form = RoomTypeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Room type created.")
            return redirect("rooms:types")
    return render(request, "rooms/roomtype_form.html", {"form": form, "mode": "create"})


@admin_or_manager_required
def roomtype_edit(request, pk):
    obj = get_object_or_404(RoomType, pk=pk)
    form = RoomTypeForm(instance=obj)
    if request.method == "POST":
        form = RoomTypeForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Room type updated.")
            return redirect("rooms:types")
    return render(request, "rooms/roomtype_form.html", {"form": form, "mode": "edit", "object": obj})


@admin_or_manager_required
def roomtype_delete(request, pk):
    obj = get_object_or_404(RoomType, pk=pk)
    if request.method == "POST":
        if obj.rooms.exists():
            messages.error(request, "Cannot delete a room type that still has rooms.")
        else:
            obj.delete()
            messages.success(request, "Room type deleted.")
        return redirect("rooms:types")
    return render(request, "partials/confirm_delete.html", {"title": "Delete room type", "object": obj})


@staff_required
def room_list(request):
    qs = Room.objects.select_related("room_type").prefetch_related("reservations")
    status = request.GET.get("status", "")
    room_type = request.GET.get("type", "")
    floor = request.GET.get("floor", "")
    q = request.GET.get("q", "").strip()
    view = request.GET.get("view", "cards")

    if status:
        qs = qs.filter(status=status)
    if room_type:
        qs = qs.filter(room_type__id=room_type)
    if floor:
        qs = qs.filter(floor=floor)
    if q:
        qs = qs.filter(
            Q(room_number__icontains=q) | Q(room_type__name__icontains=q)
        )

    paginator = Paginator(qs, 12 if view == "cards" else 20)
    page = paginator.get_page(request.GET.get("page"))

    context = {
        "rooms": page,
        "view": view,
        "statuses": Room.Status.choices,
        "room_types": RoomType.objects.all(),
        "floors": Room.objects.order_by("floor").values_list("floor", flat=True).distinct(),
        "selected": {"status": status, "type": room_type, "floor": floor, "q": q},
    }
    return render(request, "rooms/room_list.html", context)


@admin_or_manager_required
def room_create(request):
    form = RoomForm()
    if request.method == "POST":
        form = RoomForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Room created.")
            return redirect("rooms:list")
    return render(request, "rooms/room_form.html", {"form": form, "mode": "create"})


@admin_or_manager_required
def room_edit(request, pk):
    obj = get_object_or_404(Room, pk=pk)
    form = RoomForm(instance=obj)
    if request.method == "POST":
        form = RoomForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Room updated.")
            return redirect("rooms:list")
    return render(request, "rooms/room_form.html", {"form": form, "mode": "edit", "object": obj})


@admin_or_manager_required
def room_delete(request, pk):
    obj = get_object_or_404(Room, pk=pk)
    if request.method == "POST":
        if obj.reservations.exists():
            messages.error(request, "Cannot delete a room that has reservations.")
        else:
            obj.delete()
            messages.success(request, "Room deleted.")
        return redirect("rooms:list")
    return render(request, "partials/confirm_delete.html", {"title": "Delete room", "object": obj})


@admin_or_manager_required
def room_mark_available(request, pk):
    if request.method == "POST":
        room = get_object_or_404(Room, pk=pk)
        room.status = Room.Status.AVAILABLE
        room.save(update_fields=["status", "updated_at"])
        messages.success(request, f"Room {room.room_number} marked available.")
    return redirect(request.META.get("HTTP_REFERER") or "rooms:list")


@staff_required
def availability(request):
    selected = request.GET.get("date", "") or date.today().isoformat()
    try:
        target = date.fromisoformat(selected)
    except ValueError:
        target = date.today()

    rooms = list(Room.objects.select_related("room_type").filter(is_active=True))
    active = list(Reservation.ACTIVE_STATUSES)
    active_reservations = list(
        Reservation.objects.filter(
            room__is_active=True,
            booking_status__in=active,
            check_in__lt=target,
            check_out__gt=target,
        ).select_related("customer")
    )
    arriving = list(
        Reservation.objects.filter(
            room__is_active=True,
            booking_status__in=active,
            check_in=target,
        ).select_related("customer")
    )

    occupied_by_room = {r.room_id: r for r in active_reservations}
    arriving_by_room = {r.room_id: r for r in arriving}

    rows = []
    for room in rooms:
        guest = ""
        booking_id = ""
        if room.id in occupied_by_room:
            state = "occupied"
            res = occupied_by_room[room.id]
        elif room.id in arriving_by_room:
            state = "reserved"
            res = arriving_by_room[room.id]
        elif room.status == Room.Status.AVAILABLE:
            state = "available"
            res = None
        else:
            state = room.status
            res = None
        if res is not None:
            guest = res.customer.full_name
            booking_id = res.booking_id
        rows.append({"room": room, "state": state, "guest": guest, "booking_id": booking_id})

    summary = {}
    for row in rows:
        summary[row["state"]] = summary.get(row["state"], 0) + 1

    return render(
        request,
        "rooms/availability.html",
        {
            "rows": rows,
            "target": target,
            "summary": summary,
            "rooms_total": len(rows),
        },
    )
