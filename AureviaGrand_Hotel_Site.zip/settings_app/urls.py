from django.urls import path

from settings_app import views

app_name = "settings_app"

urlpatterns = [
    path("", views.index, name="index"),
]
