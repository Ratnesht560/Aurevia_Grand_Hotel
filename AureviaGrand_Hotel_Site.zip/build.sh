#!/usr/bin/env bash
set -euo pipefail

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

python manage.py check
python manage.py migrate --noinput
python manage.py collectstatic --noinput

if [[ "${SEED_DEMO_DATA:-False}" == "True" || "${SEED_DEMO_DATA:-False}" == "true" ]]; then
    python manage.py seed_data
fi
