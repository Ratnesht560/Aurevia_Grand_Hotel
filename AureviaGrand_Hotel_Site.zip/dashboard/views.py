"""Dashboard: KPIs and chart data, all computed from the database."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.utils import timezone

from bookings.models import Reservation
from core.decorators import staff_required
from core.utils import last_n_days, serialize_chart_date
from customers.models import Customer
from django.shortcuts import render
from payments.models import Payment
from rooms.models import Room


@staff_required
def index(request):
    today = timezone.localdate()
    day_start = timezone.make_aware(timezone.datetime.combine(today, timezone.datetime.min.time()))

    rooms = Room.objects.all()
    active_statuses = list(Reservation.ACTIVE_STATUSES)

    context = {
        "kpis": compute_kpis(rooms, today, day_start),
        "charts": compute_charts(rooms, today, active_statuses),
        "today": today,
    }
    return render(request, "dashboard/dashboard.html", context)


def compute_kpis(rooms, today, day_start):
    total_rooms = rooms.filter(is_active=True).count()
    available = rooms.filter(status=Room.Status.AVAILABLE, is_active=True).count()
    occupied = rooms.filter(status=Room.Status.OCCUPIED, is_active=True).count()
    active = list(Reservation.ACTIVE_STATUSES)

    today_ins = Reservation.objects.filter(
        check_in=today, booking_status__in=active
    ).count()
    today_outs = Reservation.objects.filter(
        check_out=today, booking_status__in=[Reservation.BookingStatus.CHECKED_IN, Reservation.BookingStatus.CONFIRMED]
    ).count()
    active_bookings = Reservation.objects.filter(booking_status__in=active).count()
    customers = Customer.objects.count()
    today_revenue = (
        Payment.objects.filter(date__gte=day_start).aggregate(t=Sum("amount"))["t"] or Decimal("0")
    )

    return {
        "total_rooms": total_rooms,
        "available_rooms": available,
        "occupied_rooms": occupied,
        "today_checkins": today_ins,
        "today_checkouts": today_outs,
        "active_bookings": active_bookings,
        "total_customers": customers,
        "today_revenue": today_revenue,
    }


def compute_charts(rooms, today, active_statuses):
    days = last_n_days(14)
    fmt_days = [serialize_chart_date(d) for d in days]
    day_start_list = [timezone.make_aware(timezone.datetime.combine(d, timezone.datetime.min.time())) for d in days]

    revenue_map = {}
    for start, d in zip(day_start_list, days):
        end = start + timedelta(days=1)
        revenue_map[d] = (
            Payment.objects.filter(date__gte=start, date__lt=end).aggregate(t=Sum("amount"))["t"] or Decimal("0")
        )

    bookings_map = {}
    for d in days:
        start = timezone.make_aware(timezone.datetime.combine(d, timezone.datetime.min.time()))
        end = start + timedelta(days=1)
        bookings_map[d] = Reservation.objects.filter(
            created_at__gte=start, created_at__lt=end
        ).count()

    # status distribution
    status_counts = {
        s: rooms.filter(status=s).count() for s, _ in Room.Status.choices
    }
    status_labels = [str(dict(Room.Status.choices)[s]) for s, _ in Room.Status.choices]

    # room types distribution
    type_rows = (
        rooms.values("room_type__name").annotate(count=Count("id")).order_by("room_type__name")
    )
    type_labels = [row["room_type__name"] for row in type_rows]
    type_values = [row["count"] for row in type_rows]

    return {
        "revenue_labels": fmt_days,
        "revenue_values": [float(revenue_map[d]) for d in days],
        "bookings_labels": fmt_days,
        "bookings_values": [bookings_map[d] for d in days],
        "status_labels": status_labels,
        "status_values": [status_counts[s] for s, _ in Room.Status.choices],
        "type_labels": type_labels,
        "type_values": type_values,
    }
