"""Context processor exposing site-wide settings to every template."""
from core.models import Hotel, NotificationSetting
from core.utils import brand_initials


def site_settings(request):
    hotel = Hotel.get_instance()
    notifications = NotificationSetting.get_instance()
    return {
        "hotel": hotel,
        "notifications": notifications,
        "brand_name": hotel.name,
        "brand_tagline": hotel.tagline,
        "brand_initials": brand_initials(hotel.name),
        "site_debug": __import__("django.conf", fromlist=["settings"]).settings.DEBUG,
    }
