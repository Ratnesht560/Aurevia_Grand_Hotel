"""Reports: revenue, occupancy, bookings and customers with CSV export."""
import csv
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.db.models.functions import TruncDate
from django.http import HttpResponse
from django.shortcuts import render

from bookings.models import Reservation
from core.decorators import staff_required
from customers.models import Customer
from payments.models import Payment
from rooms.models import Room


def _range(request):
    today = date.today()
    preset = request.GET.get("range", "month")
    default_end = today
    default_start = {
        "day": today,
        "week": today - timedelta(days=6),
        "month": today - timedelta(days=29),
        "custom": today - timedelta(days=29),
    }.get(preset, today - timedelta(days=29))

    start = request.GET.get("start", default_start.isoformat())
    end = request.GET.get("end", default_end.isoformat())
    try:
        start_d = date.fromisoformat(start)
    except ValueError:
        start_d = default_start
    try:
        end_d = date.fromisoformat(end)
    except ValueError:
        end_d = default_end
    if end_d < start_d:
        start_d, end_d = end_d, start_d
    return start_d, end_d, preset


@staff_required
def index(request):
    start, end, preset = _range(request)
    report = request.GET.get("report", "revenue")
    context = {
        "report": report,
        "start": start,
        "end": end,
        "preset": preset,
        "currency": "₹",
        "url_base": request.path,
    }

    if report == "revenue":
        context.update(revenue_report(start, end))
    elif report == "occupancy":
        context.update(occupancy_report(start, end))
    elif report == "bookings":
        context.update(bookings_report(start, end))
    else:
        context.update(customers_report(start, end))
    return render(request, "reports/index.html", context)


def revenue_report(start, end):
    qs = Payment.objects.filter(date__date__gte=start, date__date__lte=end)
    rows = (
        qs.annotate(day=TruncDate("date"))
        .values("day")
        .annotate(amount=Sum("amount"))
        .order_by("day")
    )
    by_method = (
        qs.values("method").annotate(amount=Sum("amount")).order_by("-amount")
    )
    total = sum((r["amount"] for r in rows), Decimal("0"))
    method_labels = [
        dict(Payment.Method.choices)[m["method"]] for m in by_method
    ]
    return {
        "total_revenue": total,
        "revenue_rows": [{"day": r["day"], "amount": r["amount"]} for r in rows],
        "by_method": [
            {"method": dict(Payment.Method.choices)[m["method"]], "amount": m["amount"]}
            for m in by_method
        ],
        "method_labels": method_labels,
        "method_values": [float(m["amount"]) for m in by_method],
    }


def occupancy_report(start, end):
    rooms = Room.objects.filter(is_active=True)
    total = rooms.count()
    status_counts = {s: rooms.filter(status=s).count() for s, _ in Room.Status.choices}
    occupied = status_counts.get(Room.Status.OCCUPIED, 0)

    # reservations active during the window
    res = Reservation.objects.filter(
        booking_status__in=Reservation.ACTIVE_STATUSES,
        check_in__lte=end,
        check_out__gte=start,
    )
    day_counts = []
    d = start
    while d <= end:
        on_day = res.filter(check_in__lte=d, check_out__gt=d).count()
        day_counts.append({"day": d, "occupied": on_day})
        d += timedelta(days=1)
    if day_counts:
        avg = sum(r["occupied"] for r in day_counts) / len(day_counts)
    else:
        avg = 0

    return {
        "total_rooms": total,
        "occupied": occupied,
        "available": status_counts.get(Room.Status.AVAILABLE, 0),
        "reserved": status_counts.get(Room.Status.RESERVED, 0),
        "cleaning": status_counts.get(Room.Status.CLEANING, 0),
        "maintenance": status_counts.get(Room.Status.MAINTENANCE, 0),
        "out_of_service": status_counts.get(Room.Status.OUT_OF_SERVICE, 0),
        "occupancy_percent": round(avg * 100 / total) if total else 0,
        "day_counts": day_counts,
        "status_rows": [
            {"status": str(dict(Room.Status.choices)[s]), "value": v, "code": s}
            for s, v in status_counts.items()
        ],
    }


def bookings_report(start, end):
    qs = Reservation.objects.filter(check_in__gte=start, check_in__lte=end)
    status_counts = {
        s: qs.filter(booking_status=s).count() for s, _ in Reservation.BookingStatus.choices
    }
    total = qs.count()
    revenue = (
        qs.filter(booking_status=Reservation.BookingStatus.CHECKED_OUT)
        .aggregate(t=Sum("total"))["t"] or Decimal("0")
    )
    return {
        "booking_total": total,
        "booking_revenue": revenue,
        "booking_status_counts": [
            {"status": str(dict(Reservation.BookingStatus.choices)[s]), "count": c}
            for s, c in status_counts.items()
        ],
        "booking_rows": qs.select_related("customer", "room").order_by("-check_in")[:200],
    }


def customers_report(start, end):
    new_customers = Customer.objects.filter(created_at__date__gte=start, created_at__date__lte=end)
    all_customers = Customer.objects.annotate(res_count=Count("reservations"))
    returning = all_customers.filter(res_count__gte=2)
    frequent = all_customers.filter(res_count__gte=3)
    return {
        "new_customers_count": new_customers.count(),
        "returning_customers_count": returning.count(),
        "frequent_customers_count": frequent.count(),
        "total_customers_count": all_customers.count(),
        "new_customer_rows": new_customers.order_by("-created_at")[:100],
        "frequent_customer_rows": frequent.order_by("-res_count")[:20],
    }


@staff_required
def export_csv(request, report):
    start, end, preset = _range(request)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = (
        f'attachment; filename="aurevia_{report}_{start}_{end}.csv"'
    )
    writer = csv.writer(response)
    writer.writerow([f"Aurevia Grand - {report.title()} report"])
    writer.writerow([f"{start} to {end}"])
    writer.writerow([])

    if report == "revenue":
        data = revenue_report(start, end)
        writer.writerow(["Date", "Amount"])
        for row in data["revenue_rows"]:
            writer.writerow([row["day"], row["amount"]])
        writer.writerow(["Total", data["total_revenue"]])
        writer.writerow([])
        writer.writerow(["Payment method", "Amount"])
        for row in data["by_method"]:
            writer.writerow([row["method"], row["amount"]])
    elif report == "bookings":
        data = bookings_report(start, end)
        writer.writerow(["Status", "Count"])
        for row in data["booking_status_counts"]:
            writer.writerow([row["status"], row["count"]])
        writer.writerow([])
        writer.writerow(["Booking ID", "Guest", "Room", "Check-in", "Check-out", "Total", "Status"])
        for r in data["booking_rows"]:
            writer.writerow(
                [r.booking_id, r.customer.full_name, r.room.room_number,
                 r.check_in, r.check_out, r.total, r.get_booking_status_display()]
            )
    elif report == "customers":
        data = customers_report(start, end)
        writer.writerow(["Name", "Email", "Phone", "City", "Joined", "Bookings"])
        for c in data["new_customer_rows"]:
            writer.writerow([c.full_name, c.email, c.phone, c.city, c.created_at.date(), c.reservations.count()])
    elif report == "occupancy":
        data = occupancy_report(start, end)
        writer.writerow(["Metric", "Value"])
        for key in ["total_rooms", "occupied", "available", "reserved", "cleaning", "maintenance", "out_of_service"]:
            writer.writerow([key.replace("_", " ").title(), data[key]])
    return response
