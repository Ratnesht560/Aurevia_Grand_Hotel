from django.contrib import admin

from payments.models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("payment_id", "reservation", "customer", "amount", "method", "date")
    list_filter = ("method", "date")
    search_fields = (
        "payment_id", "reference", "reservation__booking_id",
        "customer__first_name", "customer__last_name",
    )
    list_select_related = ("reservation", "customer")
    readonly_fields = ("payment_id", "date")
    date_hierarchy = "date"
